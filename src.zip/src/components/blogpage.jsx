import React from 'react'

function blogpage() {
  return (
    <div>blogpage</div>
  )
}

export default blogpage