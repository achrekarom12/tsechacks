import React from "react";
import "./blogs.css";

function blogs() {
  return (
    <>
      <div>
        <table>
          <tr>
            <tr>
              <div className="cards m-2">
                <h3 className="cards__title">
                  <a href="https://www.csestack.org/pytron-competitive-programming-questions-practice/">
                    Blog 1
                  </a>
                </h3>
                <p className="cards__content">
                  Click on the above link to view the blog 1.{" "}
                </p>
                {/* <div className="cards__date">April 15, 2022</div> */}
              </div>
            </tr>

            <tr>
              <div className="cards m-2">
                <h3 className="cards__title">
                  <a href="https://www.edureka.co/blog/interview-questions/pytron-interview-questions/">
                    Blog 2
                  </a>
                </h3>
                <p className="cards__content">Click on the above link to view the blog 2.{" "}
 </p>
                {/* <div className="cards__date">April 15, 2022</div> */}
              </div>
            </tr>

            <tr>
              <div className="cards m-2">
                <h3 className="cards__title">
                  <a href="https://www.ntegral.com/products/data-science-virtual-desktop-ubuntu-22-04?msclkid=aa7bc68721d01bec158da54cacafe7b9">
                    Blog 3
                  </a>
                </h3>
                <p className="cards__content">
                Click on the above link to view the blog 3.{" "}
                </p>
                {/* <div className="cards__date">April 15, 2022</div> */}
              </div>
            </tr>

            <tr>
              <div className="cards m-2">
                <h3 className="cards__title">
                  <a href="https://www.ntegral.com/products/data-science-virtual-desktop-ubuntu-22-04?msclkid=aa7bc68721d01bec158da54cacafe7b9">
                    Blog 4
                  </a>
                </h3>
                <p className="cards__content">
                Click on the above link to view the blog 4.{" "}
                </p>
                {/* <div className="cards__date">April 15, 2022</div> */}
              </div>
            </tr>
          </tr>
        </table>
      </div>
    </>
  );
}

export default blogs;
