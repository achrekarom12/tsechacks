import React from 'react'

function jobs() {
  return (
    <div>
        <h1>Jobs Available</h1>
    </div>
  )
}

export default jobs